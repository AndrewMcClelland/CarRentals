<!DOCTYPE html>
<html lang="en">
<head>
<title>Monthly Invoice</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://bootswatch.com/superhero/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container-fluid">
</div>

<?php
  include('session.php');
  ?>
  <h4> Hi Admin <?php echo $_SESSION["adminEmail"] ?></h4>
  <!-- associate buton with it -->
  <form name="logout" method="POST" action="logout.php">
  <input value="btnLogout" type="hidden" name="Logout" >
  <input type="submit"  value="Logout">
  </form>

  <form name="homepage" method="POST" action="goToAdminHomepage.php">
  <input value="btnHomepage" type="hidden" name="Back" >
  <input type="submit"  value="Back">
  </form>

<?php

    $host = "localhost";
    $user = "root";
    $password = "";
    $database = "KTCS";

    $cxn = mysqli_connect($host,$user,$password, $database);

    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        die();
    }


    $memberID = $_POST["memID"];
    $dateToStart = $_POST["monthStat"];
    $dateToEnd = $_POST["endMonthStat"];
    // Need to query all results for the given date
    $sqlQuery = "select *
                 from Payment_History
                 where Payment_History.Date>='$dateToStart' and Payment_History.Date <= '$dateToEnd'
                 and MemberID=$memberID";

    $resultVal = mysqli_query($cxn, $sqlQuery);
    if (mysqli_num_rows($resultVal) > 0)
    {
      $startMonth = date("F", strtotime($dateToStart));
      ?>
      <h3> Invoice: </h3>
      <?php
  		while($row = mysqli_fetch_assoc($resultVal))
      {
        $dateFormattedPaidObject = date("F d", strtotime($row["Date"]));
          ?>
          <h5><b>MemberID: </b> <?php echo $memberID ?></h5>
          <h5><b>Amount Paid: </b>$<?php echo $row["Amount"] ?></h5>
          <h5><b>Date Paid: </b><?php echo $dateFormattedPaidObject ?></h5>
          <h5><b>Description: </b><?php echo $row["Description"] ?></h5>
          <br></br>
        <?php
      }
    }
    else
    {?>
        <h4>Sorry there are no invoices for the given dates specified.</h4>
    <?php }
    ?>



</body>
</html>
