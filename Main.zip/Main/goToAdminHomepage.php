<?php
  header("Location: adminHomePage.php");
?>
